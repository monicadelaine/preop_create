package edu.ua.cs.robotics.rdis;
import java.util.Arrays;
import java.util.Random;

import org.python.core.PyArray;
import org.python.core.PyInteger;
import org.python.core.PyList;
import org.python.core.PyObject;
import org.python.core.PyTuple;
import org.python.modules.struct;
import org.python.util.PythonInterpreter;

import junit.framework.TestCase;


public class RDISTest extends TestCase implements RDIS.Callback {
	
	protected RDIS mModel;
	
	protected Random mRNG = new Random();
	
	protected byte[] mTest;
	
	protected byte[] mBytesLastRead;
	
	protected void setUp() {
		mModel = new RDIS();
		
		new PythonInterpreter();
		
		mModel.addConnection(new Connection(mModel, "connection") {
			protected void onStartup(String portName) throws RDISException {	}
			protected void onKeepalive() { }
			protected void onTerminate() { }

			protected void onWrite(byte[] stuff) throws RDISException {
				assertEquals(stuff, mTest);
			}

			protected byte[] onRead(int num) throws RDISException {
				byte b[] = new byte[num];
				mRNG.nextBytes(b);
				mBytesLastRead = b;
				return b;
			}
		});
		
		mModel.addStateVariable(
				StateVariable.newInteger("stateVar")
		);
		
		mModel.addInterface(
				new Interface(mModel,
						"someInterface",
						"adhoc",
						new String[] {"a", "b"},
						null,
						new Call[]{
								new Call(
										"fixedWidthTest",
										new String[] {"<a + b>"}
								)
						}
				)
		);
		
		mModel.addPrimitive(
				Primitive.newFixedWidth(
						mModel,
						"fixedWidthTest",
						new String[] {"someArg"},
						"connection",
						new String[] {"<42>", "<someArg>"},
						new String[] {"stateVar = __out__[0]"},
						">BB",
						">B")
		);
	}
	
	public void testInterface() throws RDISException {
		assertInterfaceWrites("someInterface",
				new PyInteger[] {new PyInteger(1), new PyInteger(2)},
				new byte[] {42, 3});
	}
	
	public void testFixedWidthPrimitive() throws RDISException {
		assertPrimitiveWrites("fixedWidthTest", new PyInteger[] {new PyInteger(42)}, new byte[] {42, 42});
		
		
		StateVariable sv = mModel.getStateVariable("stateVar");
		int real = mBytesLastRead[0];
		
		// Force it to be unsigned.
		if(real < 0) real += 256;
		
		assertEquals(real, sv.getInt());
	}
	
	private void assertInterfaceWrites(String string, PyObject[] args, byte[] bs) throws RDISException {
		mTest = bs;
		mModel.callInterface(string, args);
	}

	private void assertPrimitiveWrites(String name, PyObject[] args, byte[] bs) throws RDISException {
		mTest = bs;
		mModel.callPrimitive(name, args);
	}
	
	private void assertEquals(byte a[], byte b[]) {
		assertTrue( Arrays.equals(a, b) );
	}

	public void onMessageReceived(String name, DomainAdapter contents) {
		
	}
}
